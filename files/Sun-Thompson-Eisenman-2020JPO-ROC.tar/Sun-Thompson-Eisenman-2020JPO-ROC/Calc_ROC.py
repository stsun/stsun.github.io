#!/bin/env python
'''
Parameters are defined in share/configure.py
'''

from share import ROC_Python as RP
import glob
import pythonstartup as ps
import time

pdir = "/glade/u/home/shantong/scratch/AbruptCO2/monthly/"
def main(run="ctl", years=[0]):
    if run == "ctl":
        fdir = pdir + "ctl"
        case = "b40.1850.track1.1deg.006.pop.h."
        year0= 251
    elif run == "co2":
        fdir = pdir + "co2"
        case = "b40.abrupt4xco2.1deg.001.pop.h."
        year0= 1850
    else:
        print("Error")

    for year in years:
        print("I am working on %s%4.4d"%(case, year0+year))
        list_files = glob.glob(fdir+"/%s%4.4d-*.nc"%(case, year0+year))
        list_files.sort()
        foutput    = case + "%4.4d.bin"%(year0+year)
        bb         = RP.driver(list_files[0:12:4], foutput)
    return 0

main()
