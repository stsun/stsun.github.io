#!/glade/u/home/shantong/.local/bin/python
'''
Parameters are defined in share/configure.py
'''

from share import ROC_Python as RP
import glob
import pythonstartup as ps
import time
import multiprocessing as mp

pdir = "/glade/u/home/shantong/scratch/AbruptCO2/monthly/"
def main(run, years):
    if run == "ctl":
        fdir = pdir + "ctl"
        case = "b40.1850.track1.1deg.006.pop.h."
        year0= 251
    elif run == "co2":
        fdir = pdir + "co2"
        case = "b40.abrupt4xco2.1deg.001.pop.h."
        year0= 1850
    else:
        print("Error")

    for year in years:
        print("I am working on %s%4.4d"%(case, year0+year))
        list_files = glob.glob(fdir+"/%s%4.4d-*.nc"%(case, year0+year))
        list_files.sort()
        foutput    = case + "%4.4d.bin"%(year0+year)
        bb         = RP.driver(list_files, foutput)
    return 0

# We will use multi-processing
#args   = []
#nproc  = 10
jobs   = []
for run in ["ctl", "co2"]:
    for i in range(0, 5):
        #arg = [(run, range(i*50, (i+1)*50))]
        #args.append(arg)
        print("Submit jobs for %s-%i"%(run, i))
        years = range(i*50, (i+1)*50)
        p     = mp.Process(target=main, args=(run, years))
        jobs.append(p)
        p.start()

for p in jobs:
    p.join()        

#ps.use_multiprocessing(nproc, target=main, args=args)
