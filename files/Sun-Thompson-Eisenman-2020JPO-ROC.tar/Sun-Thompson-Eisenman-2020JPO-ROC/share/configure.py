'''Information to calculate the residual-mean overturning circulation
on potential density coordinate, such as the data information, grid
information, and potential density levels.
'''
import cesm_parm as cparm
import pythonstartup as ps
import numpy as np


p5    = 0.5
ffac  = 5        # refine the vertical grid by dividing each vertical grid into ffac part
p_r   = 2000.0   # reference pressure
pdlev = [1, 10, 20] + list(np.arange(26.2, 34.01, 0.1)) + list(np.arange(34.1,36.51,0.05))+\
        list(np.arange(36.55, 38.001, 0.01))
#pdlev = [1, 10, 20] + list(np.arange(25, 45, 0.1))

dir_out  = "/glade/u/home/shantong/work/AMOC_Warming/ROC/output/" # output directory
#dir_tmp  = "/home/stsun/work/AMOC_Warming/Compute_ROC/tmp"     # tmp files

# grid information
FG    = cparm.grid_file
dz    = ps.ncread(FG, "dz")
TLAT  = ps.ncread(FG, "TLAT")
ULAT  = ps.ncread(FG, "ULAT")
z_t   = ps.ncread(FG, "z_t")
KMU   = ps.ncread(FG, "KMU", fill_value=0)
KMT   = ps.ncread(FG, "KMT", fill_value=0)
DXU   = ps.ncread(FG, "DXU")
DYU   = ps.ncread(FG, "DYU")
HTE   = ps.ncread(FG, "HTE")
HTN   = ps.ncread(FG, "HTN")
TA    = ps.ncread(FG, "TAREA")
UA    = ps.ncread(FG, "UAREA")
RM    = ps.ncread(FG, "REGION_MASK", fill_value=0)

ny,nx = np.shape(KMT)
nz    = np.size(z_t)
nd    = len(pdlev)

# Refine the vertical grid
nzf   = nz*ffac
KMUf  = KMU * ffac
KMTf  = KMT * ffac
dzf   = np.zeros(nzf, dtype=np.float32)
zzf   = np.zeros(nzf, dtype=np.float32)
for k in range(0, nz):
    dzf[k*ffac:(k+1)*ffac] = dz[k]/ffac
zzf   = np.cumsum(dzf) - dzf/2.0
dz3   = np.repeat(np.repeat(dzf.reshape(nzf, 1, 1), ny, axis=1), nx, axis=2)

# Load the inerpolation index matrix from T to U grid using "quadratic polynomial interpolation"
c_T2U = np.fromfile("share/InterpIndex_T2Ugrid.bin", dtype=np.double).reshape(ny, nx, 4)

# load overflow region: overflow parameterization is included in POP2,
# extra convergence must be compensated over overflow region
OF  = ps.read_regular_text("share/overflow")
nof = np.size(OF, axis=0)
for k in range(0, nof):
    if OF[k, 3] == 1:   # Position of overflow
        OF[k, 0] = OF[k,0]+1
    elif OF[k, 3] == 3:
        OF[k, 0] = OF[k,0]-1
    elif OF[k, 3] == 2:
        OF[k, 1] = OF[k,1]+1
    else:
        OF[k, 1] = OF[k,1]-1
    OF[k, 0:3] = OF[k, 0:3] -1   # index starts at 0 in python
# Column-1: x; Column-2: y; Column 3: z; Colum 4: direction


# Define vertical interpolation index
k_p   = 0
w_p   = 1
k_n   = 2
w_n   = 3

kw    = np.zeros((nzf, 4),dtype=np.float32)
for k in range(0, nzf):
    kw[k, k_p] = int(np.ceil((k+1)/ffac-p5))-1
    kw[k, k_n] = kw[k,0] + 1
    if kw[k,k_p] < 0:
        kw[k, k_p] = 0
        kw[k, w_p] = 0
        kw[k, w_n] = 1
    elif kw[k, k_n] > nz-1:
        kw[k, k_n] = nz-1
        kw[k, w_p] = 1
        kw[k, w_n] = 0
    else:
        kw[k, w_p] = (z_t[int(kw[k, k_n])]-zzf[k])/(z_t[int(kw[k, k_n])] - z_t[int(kw[k, k_p])])
        kw[k, w_n] = 1-kw[k, w_p]

# Variable names in the nc files
VV = ["UVEL", "VVEL", "UISOP", "VISOP", "USUBM", "VSUBM"]
TT = ["TEMP", "SALT"]
