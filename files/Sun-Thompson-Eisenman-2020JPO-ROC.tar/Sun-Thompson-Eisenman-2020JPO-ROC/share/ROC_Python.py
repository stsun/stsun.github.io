'''This python code include most of the python functions to calculate
the Residual-mean overturning circulation streamfunction for cesm (1deg)
'''
import pythonstartup as ps
import pickle
import Density as ds

from share.configure import *
from share import ROC_Fortran as RF
#-------define or load coordinate variables-------------

def Interp_T_to_UGrid(T):
    '''
    This will interpolate T from T-grid onto U-grid.
    T should be in 3D.
    Be careful, T shuld be filled by NaN
    '''
    TU = np.zeros((nz, ny, nx), dtype=np.float32)
    for i in range(0, ny-1):
        for j in range(0, nx):
            ip1       = i+1
            jp1       = j+1
            if jp1>= nx:
                jp1 = 0
            TU[:,i,j] = T[:,i,j]*c_T2U[i,j,0] + T[:,i,jp1]*c_T2U[i,j,1] + \
                        T[:,ip1,j]*c_T2U[i,j,2] + T[:,ip1,jp1]*c_T2U[i,j,3]

    return TU

def Interp_U_Density_z(D, velocity=False, density_on_U=False, density_on_T=False, eddy=False):
    '''
    Here we interpolate density or velocity onto a finer grid
    '''
    Df  = np.zeros((nzf, ny, nx), dtype=np.float32)
    
    if velocity:
        for k in range(0, nz):
            Df[k*ffac:(k+1)*ffac, :, :] = D[k, :, :]
        return Df
    elif density_on_U:
        for k in range(0, nzf):
            Df[k, :, :] = D[int(kw[k,k_p]),:,:]*kw[k,w_p] + D[int(kw[k, k_n]),:,:]*kw[k,w_n]

        # Correction for bottom cell -- on U grid
        for i in range(0, ny):
            for j in range(0, nx):
                ku = KMU[i,j]
                if ku>=1 and ku<nz:
                    Df[(ku-1)*ffac+int(ffac/2):ku*ffac, i,j] = D[ku-1,i,j]
        if eddy:
            # The eddy bolus velocity does not satisfy the non-slip boundary condition
            for i in range(0, ny):
                for j in range(0, nx):
                    ku  = KMU[i,j]
                    kuf = ku * ffac
                    if ku>1 and ku<nz:
                        Df[kuf:, i, j] = D[ku-1, i, j]
        return Df
    elif density_on_T:
        for k in range(0, nz*ffac):
            Df[k, :, :] = D[int(kw[k,k_p]),:,:]*kw[k, w_p] + D[int(kw[k,k_n]),:,:]*kw[k,w_n]

        # Correct for the bottom cell --- Be careful, density is on T-grid in this case
        for i in range(0, ny):
            for j in range(0, nx):
                ku = KMT[i,j]
                if ku>1 and ku<nz:
                    Df[(ku-1)*ffac+int(ffac/2):ku*ffac, i, j] = D[ku-1, i,j]
                        
        return Df
    else:
        print("Error: Input error for Interp_U_Density_z!!")
        return 0


def vertical_integration(V, TS):
    '''
    vertical integration of variables below isopycnals
    '''
    T  = TS["TEMP"].squeeze()
    S  = TS["SALT"].squeeze()
    if np.ndim(T) != 3:
        print("Error: dimension error in vertical_integration!!")
        
    sigma2 = ds.calc_pd(S, T, p=p_r) - 1000.0
    
    U0 = V["UVEL"].squeeze()
    V0 = V["VVEL"].squeeze()
    U1 = (V["UISOP"] + V["USUBM"]).squeeze()
    V1 = (V["VISOP"] + V["VSUBM"]).squeeze()

    # Interpolate density to U-Grid
    sigma_u = RF.interp_t_to_ugrid(sigma2, c_T2U, nx, ny, nz)
    #sigma_u = Interp_T_to_UGrid(sigma2)

    # Interpolate U and sigma to finer z grid
    U0f    = Interp_U_Density_z(U0, velocity=True)
    V0f    = Interp_U_Density_z(V0, velocity=True)
    U1f    = Interp_U_Density_z(U1, velocity=True)
    V1f    = Interp_U_Density_z(V1, velocity=True)
    sigmaf = Interp_U_Density_z(sigma_u, density_on_U=True)
    sigmafe= Interp_U_Density_z(sigma_u, density_on_U=True, eddy=True)

    # To reduce memory use, let's reuse U0f,V0f,U1f, andd V1f
    U0f   = U0f * dz3
    V0f   = V0f * dz3
    U1f   = U1f * dz3
    V1f   = V1f * dz3
                          
    # Integration of V/U below isopycnals
    nd    = len(pdlev)
    FU0   = np.zeros((nd, ny, nx), dtype=np.float32)
    FV0   = np.zeros((nd, ny, nx), dtype=np.float32)
    FU1    = np.zeros((nd, ny, nx), dtype=np.float32)
    FV1    = np.zeros((nd, ny, nx), dtype=np.float32)
    # This contains the integration of dz from surface to the specified isopycnal
    # Reference: Nurser and Lee, 2004, JPO
    zv     = np.zeros((nd, ny, nx), dtype=np.float32)

    sigmaf[np.isnan(sigmaf)]   = -1.e4
    sigmafe[np.isnan(sigmafe)] = -1.e4

    FU0,FV0,FU1,FV1,zv  = RF.integrateuv(U0f,V0f,U1f,V1f,dz3,sigmaf,sigmafe,pdlev,nx,ny,nzf,nd)

    # Find overflow compensation for convergence/divergence
    # Extra divergence is introduced at the neighbouring pints of overflow, which should be compensated.
    COV    = np.zeros((nd, ny, nx),dtype=np.float32)
    for i in range(0, ny):
        for j in range(0, nx):
            ku    = KMU[i,j]
            U0[0:ku, i,j] = 0
            V0[0:ku, i,j] = 0

    for k in range(0, nof):
        lx  = OF[k, 0]
        ly  = OF[k, 1]
        lz  = OF[k, 2]
        
        den = sigma2[lz, ly, lx]
        ld  = (pdlev<=den).sum()
        lxm1= lx-1
        lym1= ly-1
        
        overflow = p5*(U0[lz, ly, lx]  *DYU[ly, lx]  + U0[lz, lym1, lx]  *DYU[lym1,lx]   -\
                       U0[lz, ly, lxm1]*DYU[ly, lxm1]- U0[lz, lym1, lxm1]*DYU[lym1,lxm1] +\
                       V0[lz, ly, lx]  *DXU[ly, lx]  + V0[lz, ly,   lxm1]*DXU[ly, lxm1]  -\
                       V0[lz, lym1,lx] *DXU[lym1, lx]- V0[lz, lym1, lxm1]*DXU[lym1,lxm1]) *\
                       dz[lz]
        COV[0:ld, ly, lx] = overflow

    # Now return the results
    result = {}
    result["FU0"] = FU0
    result["FV0"] = FV0
    result["FU1"] = FU1
    result["FV1"] = FV1
    result["COV"] = COV
    result["zv"]  = zv

    return result

def obtain_diapycnal_flux(list_file):
    '''
    Here we accumulate variables in time space and calculate the "diapycnal flux"
    Note that this is not diapycnal flux if not in equilibration!!!!
    default: each file contains a single time slice
    '''
    for n,filen in enumerate(list_file):
        fn  = filen.split("/")[-1]
        print("Accumulate file: %s"%(fn))
        TS  = ps.ncread(filen, TT, fill=True, fill_value=np.nan)
        V   = ps.ncread(filen, VV, fill=True, fill_value=0)
        VINT= vertical_integration(V, TS)

        if n == 0:
            RR = VINT
        else:
            for varn in VINT.keys():
                RR[varn] = RR[varn] + VINT[varn]

    nt  = len(list_file)
    # -- Now we calculate the diapycnal flux, note that this is not
    # -- diapycnal flux if not in equilibration. We are just using the
    # -- volume conservation to show the streamfunction
    FU0  = RR["FU0"]
    FV0  = RR["FV0"]
    FU1  = RR["FU1"]
    FV1  = RR["FV1"]
    COF  = RR["COV"]  # Compensation for overflow

    # We calculate the divergence
    C0   = np.zeros((nd, ny, nx), dtype=np.float32)   # mean flow part
    C1   = np.zeros((nd, ny, nx), dtype=np.float32)   # eddy part
    for ly in range(0, ny):
        for lx in range(0, nx):
            lxm1  = lx-1
            lym1  = ly-1
            C0[:, ly, lx] = p5*(FU0[:, ly, lx]   *DYU[ly, lx]   + FU0[:, lym1, lx]  *DYU[lym1, lx]   - \
                                FU0[:, ly, lxm1] *DYU[ly, lxm1] - FU0[:, lym1, lxm1]*DYU[lym1, lxm1] + \
                                FV0[:, ly, lx]   *DXU[ly, lx]   + FV0[:, ly, lxm1]  *DXU[ly, lxm1]   - \
                                FV0[:, lym1,lx]  *DXU[lym1, lx] - FV0[:, lym1, lxm1]*DXU[lym1, lxm1])
            C1[:, ly, lx] = FU1[:, ly, lx] * HTE[ly, lx]  - FU1[:, ly, lxm1]*HTE[ly, lxm1] + \
                            FV1[:, ly, lx] * HTN[ly, lx]  - FV1[:, lym1, lx]*HTN[lym1, lx]
    DF   = C0+C1+COF

    Result  = {}
    Result["dflux"] = DF/nt
    Result["zv"]    = RR["zv"]/nt
    Result["FV"]    = (FV0 + FV1)/nt  # for debug
    Result["FV0"]   = FV0/nt          # for debug
    return Result

def obtain_depth_isopycnal(zv, lato, region="GLOBAL"):
    '''
    OBTAIN THE DEPTH OF ISOPYCNALS FOLLOWING NURSER AND LEE (2004)
    '''
    # There is a very deep bowl-like basin in Caribbean sea -- The current method is to remove it.
    # This will create artificial vertical displacement of isopcynals that should be flat instead.
    RM[216:251, 281:301] = 0
    IP     = ((RM==2) | (RM==3))
    ATL    = (RM>=6)
    GLB    = (RM>0)
    if region == "GLOBAL":
        MSK  = GLB
    elif region == "ATL":
        MSK  = ATL
    elif region == "IP":
        MSK  = IP
    else:
        print("No region selected!!! Options are: GLOBAL, ATL, and IP")

    # Creating bounding latitude, and volume array --- no partial bottom boundary
    nlat = len(lato)
    nd   = np.size(zv, axis=0)
    ZH   = np.zeros((nz+1, ny, nx))
    for i in range(0, ny):
        for j in range(0, nx):
            ku          = KMU[i,j]
            if ku <1:
                pass
            else:
                ZH[1:,i,j]    = np.cumsum(dz) * UA[i,j]
                ZH[ku+1:,i,j] = ZH[ku,i,j]

    zw    = np.append([0],  np.cumsum(dz))
    latb1 =( lato[0:-1] + lato[1:])/2.0
    latb  = np.append([lato[0]*2-latb1[0]], latb1)
    latb  = np.append(latb, [lato[-1]*2-latb1[-1]])

    VH    = np.zeros((nz+1, nlat))
    zd    = np.zeros((nd,   nlat))
    zv0   = np.copy(zv)
    for i in range(0, nd):
        zv0[i,:,:] = zv[i,:,:]*UA
    zv    = zv0+0.0
    for i in range(0,nlat):
        mask = ((ULAT>lato[i]-p5) & (ULAT<=lato[i]+p5) & MSK)
        Vz   = np.zeros(nz+1)
        for k in range(1, nz+1):
            Vz[k] = np.sum(ZH[k,:,:]*mask)
        for k in range(0, nd):
            VM    = np.sum(zv[k,:,:]*mask)
            kl  = ps.find_first(Vz>=VM)

            if np.isnan(kl):  # extreme value out of range--should set the maximum number in this range.
                kmax      = np.max(KMU*mask)   # KMU index is k+1, consistent.
                zd[k,i]   = zw[kmax]
            elif kl == 0:
                zd[k,i]   = 0
            else:
                rr        = (VM-Vz[kl-1])/(Vz[kl] - Vz[kl-1])
                zd[k,i]   = rr*zw[kl] + (1-rr)*zw[kl-1]
    return zd

def obtain_ROC(list_file):
    '''Here we calculate the residual-mean overturning circulation
    streamfunction: note that the meridional gradient of this
    streamfunction may not represent diapycnal flux if the circulation
    is not in equilibrium

    '''
    # This step takes most of the time
    DF    = obtain_diapycnal_flux(list_file)
    # output DF to temp files
    #with open("%s/flux.bin"%dir_tmp, "wb") as fid:
    #    pickle.dump(DF, fid)
    
    dflux = DF["dflux"]
    zv    = DF["zv"]
    FV    = DF["FV"]

    FVx   = np.sum(FV[:, 83, :],      axis=1) * DXU[83, 100] # global at 33S
    FVp   = np.sum(FV[:, 83, 53:297], axis=1) * DXU[83, 100] # Indo-Pacific
    FVa   = FVx - FVp
    
    # --- mask
    IP  = ((RM==2) | (RM==3))
    ATL = (RM>=6)

    print("Now we calculate the streamfunction ... ")
    Results= {}
    # Calculate the global overturning circulation
    region = "GLOBAL"
    Global = {}
    lato   = np.arange(-80, 71, 1)
    ny0    = len(lato)
    ROC    = np.zeros((nd, ny0))
    for i in range(0, ny0):
        MASK  = (TLAT<=lato[i])
        for k in range(0, nd):
            ROC[k,i] = np.sum(dflux[k, :, :] * MASK)
    zd     = obtain_depth_isopycnal(zv, lato, region=region)
    Global["ROC"] = -ROC/1e12
    Global["pd"]  = pdlev
    Global["zd"]  = zd
    Global["lat"] = lato

    # Calculate the Atlantic
    region   = "ATL"
    Atlantic = {}
    lato     = np.arange(-33, 71, 1)
    ny0      = len(lato)
    ROC      = np.zeros((nd, ny0))
    for i in range(0, ny0):
        MASK  = ((TLAT<=lato[i]) & ATL)
        for k in range(0, nd):
            ROC[k, i] = np.sum(dflux[k,:,:]*MASK) + FVa[k]

    zd       = obtain_depth_isopycnal(zv, lato, region=region)
    Atlantic["ROC"] = -ROC/1e12
    Atlantic["pd"]  = pdlev
    Atlantic["zd"]  = zd
    Atlantic["lat"] = lato

    # Calculate the Indo-Pacific
    region  = "IP"
    IPac    = {}
    lato    = np.arange(-33, 71, 1)
    ny0      = len(lato)
    ROC      = np.zeros((nd, ny0))
    for i in range(0, ny0):
        MASK  = ((TLAT<=lato[i]) & IP)
        for k in range(0, nd):
            ROC[k, i] = np.sum(dflux[k,:,:]*MASK) + FVp[k]

    zd       = obtain_depth_isopycnal(zv, lato, region=region)
    IPac["ROC"] = -ROC/1e12
    IPac["pd"]  = pdlev
    IPac["zd"]  = zd
    IPac["lat"] = lato

    # Results
    Results["global"]   = Global
    Results["atlantic"] = Atlantic
    Results["indo-pac"] = IPac

    return Results

def driver(list_file, foutput):
    '''
    Here is the driver to be called outside of the code
    '''
    RR = obtain_ROC(list_file)
    with open(dir_out+foutput, "wb") as fid:
        pickle.dump(RR, fid)

    return 0
    
    
